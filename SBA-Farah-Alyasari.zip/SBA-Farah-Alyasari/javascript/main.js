//The below javascript checks the email format for the sign up form and log in form

//login form email input and error message
const loginForm = document.querySelector("#login");
const loginEmailInput = loginForm.querySelector("input[type='text'][placeholder='email']");
const loginEmailErrorMessage = loginEmailInput.nextElementSibling;

//sign up form email input and error message
const signupForm = document.querySelector("#signup");
const signupEmailInput = signupForm.querySelector("input[type='text'][placeholder='Email']");
const signupEmailErrorMessage = signupEmailInput.nextElementSibling;

//regex
const emailPattern= /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

//validate email in the login form
loginEmailInput.addEventListener("input", function(){
    const emailValue = loginEmailInput.value;
    if(!emailPattern.test(emailValue)){
        loginEmailErrorMessage.textContent = "Email is not valid";
    }
    else{
        loginEmailErrorMessage.textContent = "";
    }
});

// Validate the email in the signup form
signupEmailInput.addEventListener("input", function () {
    const emailValue = signupEmailInput.value;
    if (!emailPattern.test(emailValue)) {
      signupEmailErrorMessage.textContent = "Email is not valid";
    } else {
      signupEmailErrorMessage.textContent = "";
    }
  });


  